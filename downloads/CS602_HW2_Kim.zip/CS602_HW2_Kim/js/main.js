
const apiUrl = './models/food.json';

let correctDrops = 0;

//function to fetch the food data and use async and await to process asychronous code 
async function fetchFoodData(){

    try{
        const res = await fetch(apiUrl) //location where the fetch is going to get the data
        const data = await res.json();
        totalItems = data.length;
        return data;
    } catch (err) {
        console.log('Failed to fetch food data:', err);
        return [];
    }
}

//Randomize the order of items through the map and sort method
const shuffleArray = (array) => 
    array
        .map(value => ({value, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort)
        .map(({value}) => value);

//When the user chooses to play again, the game will reset back to the initial state
function resetGame(){
    document.getElementById('completion-message').textContent = '';
    document.getElementById('header').innerHTML = 'Pick and Match Food Items';
    loadItemsButton.textContent = "Load Items";
    correctDrops = 0;

    //clear any dropped items inside the dropzones, except the category labels
    const zones = ['fruitDropZone', 'vegetableDropZone', 'dairyDropZone'];
    zones.forEach(zoneId => {
        const zone = document.getElementById(zoneId);
        [...zone.children].forEach(child => {
            if (!child.classList.contains('category-label')){
                zone.removeChild(child);
            }
        });
    })
}

//Check completion state
function checkCompletion() {
    if (correctDrops === totalItems) {
        document.getElementById('food-container').innerHTML = '';
        document.getElementById('header').innerHTML = '';

        const completionMessage = document.getElementById('completion-message');
        completionMessage.textContent = "Congratulations! You have completed the module. Click the button to play again!"
        loadItemsButton.textContent = "Play Again";
        };
    }

function isValidDrop(zoneId, foodType){
    return(
        (zoneId === 'fruitDropZone' && foodType === 'fruit') ||
        (zoneId === 'vegetableDropZone' && foodType === 'vegetable') ||
        (zoneId === 'dairyDropZone' && foodType === 'dairy')
    );
}


//When load items button is clicked, the program will fetch
document.getElementById('loadItemsButton')
.addEventListener('click', async () => {
    if (loadItemsButton.textContent === "Play Again") {
        resetGame();
        return;
    }
    // dynamic import from the foodItems module
    const module = await import('../lib/foodItems.js');
    const data = shuffleArray(await fetchFoodData());
    const container = document.getElementById('food-container');
    container.innerHTML = ''; //ensure items are refreshed everytime the button is clicked

    //draw each food and set them to draggable
    data.forEach( food => {
        const canvas = module.draw (food);
        console.log(canvas);

        //make the items draggable
        canvas.draggable = true;

        //set a custom data
        canvas.dataset.foodType = food.category;
        canvas.dataset.foodName = food.type;

        //set unique id for each food item
        const randomNumber=Math.floor(Math.random() * 1000) + 1;
        const id = `${food.type}-${randomNumber}`;
        canvas.id = id;

        console.log('Created canvas with ID:', canvas.id);

        //dragstart event when items start dragging
        canvas.addEventListener('dragstart', e => {
            e.dataTransfer.setData('text/plain', canvas.id);
            console.log('dragstart: setting ID', canvas.id);
        });

        container.appendChild(canvas);
    })
});


// Drop zones setup for each food category
const zones = ['fruitDropZone', 'vegetableDropZone', 'dairyDropZone'];
const errorMessage = document.getElementById('error-message'); //setup error message

zones.forEach(id => {
    const dropzone = document.getElementById(id);

    //Allow dragging over the dropzone
    dropzone.addEventListener('dragover', e => {
        e.preventDefault();
        dropzone.classList.add('drag-over');
        console.log('dragover on:', dropzone.id);
    });

    //When users release the item from dragging the object and dragging ends
    dropzone.addEventListener('dragleave', () =>{
        dropzone.classList.remove('drag-over', 'valid-drop', 'invalid-drop');
        errorMessage.textContent = '';
    });

    //Drop event
    dropzone.addEventListener('drop', e =>{
        e.preventDefault();
        const canvasId = e.dataTransfer.getData('text/plain');
        console.log('drop: got canvas ID', canvasId);
        const canvas = document.getElementById(canvasId);
        console.log('Found canvas:', canvas);
        const foodName = canvas.dataset.foodName;
        const foodType = canvas.dataset.foodType; 
        
        //restricted drop so the food items match the category
        if (isValidDrop(id, foodType)){
            e.preventDefault();
            dropzone.classList.add('valid-drop');
            dropzone.appendChild(canvas);
            errorMessage.textContent = ''; //when drop is valid, there are no error messages
            correctDrops++;
            checkCompletion();
        } else {
            dropzone.classList.add('invalid-drop');
            errorMessage.textContent = `Error; ${foodName} does not match in this category and cannot be placed here`;
            console.log('wrong food type: ', foodType);
        }
    });
});