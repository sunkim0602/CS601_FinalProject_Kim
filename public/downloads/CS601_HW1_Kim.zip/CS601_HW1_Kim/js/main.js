//Create references for each of the necessary elements
const firstNameInput = document.getElementById('firstName');
const lastNameInput = document.getElementById('lastName');
const emailInput = document.getElementById('email');
const subscriptionSelect = document.getElementById('subscriptionSelect');
const confirmationCheckBox = document.getElementById ('confirmation');
const submitBtn = document.getElementById('submitBtn');
const formWrapper = document.getElementById('formWrapper');
const summaryMessageDiv = document.getElementById('summaryMessage');

function validateForm(e){
    e.preventDefault(); //prevent default behavior with the submit button (reload or navigate away)
    let isValid = true;

    //validate the input for both first and last name
    const nameValidation = (name, fieldName) => {
        const errorElement = document.getElementById(`${fieldName}Error`);
        const refinedName = name.trim();
        if(refinedName.length <2 || refinedName.length > 10){
            errorElement.textContent = 'Must be between 2 - 10 characters.';
            isValid = false;
        }
        if (!/^[a-z0-9]+$/i.test(refinedName)){
            errorElement.textContent = 'Invalid. Must be alphanumeric only';
            isValid = false;
        } else{
            errorElement.textContent = '';
        }
    }


    const nameValidations = [
        { input: firstNameInput, field: 'firstName' },
        { input: lastNameInput, field: 'lastName'}
    ];

    nameValidations.forEach(({input, field}) => {
        nameValidation(input.value, field);
    });

    //validate email address
    const emailValidation = (email) => {
        const errorElement = document.getElementById ('emailError');
        if (!/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(email)){
            errorElement.textContent = 'Invalid email format.';
            isValid = false;
        } else {
            errorElement.textContent = '';
        }
    }

    emailValidation(emailInput.value);

    //Validate that a package is selected
    const subscriptionError = document.getElementById('subscriptionError');
    if (subscriptionSelect.value === 'Select') {
        subscriptionError.textContent = 'You must select a subscription package.';
        isValid = false;
    } else {
        subscriptionError.textContent = '';
    }

    //Validate that an option is chosen in the drop down menu selection
    const confirmationError = document.getElementById('confirmationError');
    if (!confirmationCheckBox.checked) {
        confirmationError.textContent = 'You must agree to the subscription terms.';
        isValid = false;
    } else {
        confirmationError.textContent = ''; // Clear error message if checkbox is checked
    }
    

    // If all validations pass, display the summary message once the form is submitted
    if (isValid) {
        const selectedPackage = subscriptionSelect.value;
        const summaryMessage = `
            <p>Thank you, ${firstNameInput.value} ${lastNameInput.value}, for subscribing!</p>
            <p>Your email <strong>${emailInput.value}</strong> is registered with our <strong>${selectedPackage}</strong> package.</p>
        `;

        summaryMessageDiv.innerHTML = summaryMessage; //Display the summary message below the form

        //After validation is complete, hide the form
        document.getElementById('contactForm').style.display = 'none';

    }
}

//initiate the form validation when the submit button is clicked
submitBtn.addEventListener('click', validateForm)

