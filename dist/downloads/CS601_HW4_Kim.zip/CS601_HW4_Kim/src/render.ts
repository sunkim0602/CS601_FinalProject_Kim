import {ICountry} from "./countries.js"

export function renderCountry (country:ICountry, container:HTMLElement | null) {
    const p = document.createElement ("p")
    container?.appendChild(country.getInfo(p));
}

