import {ICountry} from "./countries.js"
import {SnowyCountry, RainyCountry, IslandCountry} from "./models.js"

//receive country object that is of type ICountry and returns a predicate
export function isSnowyCountry (country: ICountry): country is SnowyCountry{
//checks which type of country it is
    return (country as SnowyCountry).snowLevel !==undefined; 
}

//add countries to rainy countries
export function isRainyCountry (country:ICountry): country is RainyCountry{
    return (country as RainyCountry).rainLevel !==undefined;
}

//add countries to island countries
export function isIslandCountry (country:ICountry): country is IslandCountry{
    return (country as IslandCountry).landSize !==undefined;
}