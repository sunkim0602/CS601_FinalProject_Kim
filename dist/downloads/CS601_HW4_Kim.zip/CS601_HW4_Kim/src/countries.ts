export interface ICountry{
    name: string,
    getInfo (element: HTMLElement): HTMLElement;
}