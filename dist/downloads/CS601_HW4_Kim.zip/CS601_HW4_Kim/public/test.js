import { RainyCountry, SnowyCountry, IslandCountry } from "./models.js";
import { isRainyCountry, isSnowyCountry, isIslandCountry } from "./typeGuards.js";
import { renderCountry } from "./render.js";
//prepare a list of the countries to test
const countries = [
    new RainyCountry("United States", 28),
    new SnowyCountry("Norway", 20),
    new RainyCountry("Brazil", 40),
    new IslandCountry("Japan", 145937),
    new SnowyCountry("Sweden", 30),
    new IslandCountry("Australia", 2968464)
];
const allCountriesList = [];
const rainyCountriesList = [];
const snowyCountriesList = [];
const islandCountriesList = [];
const allCountriesContainer = document.getElementById("all-countries");
const snowyCountriesContainer = document.getElementById("snowy-countries");
const rainyCountriesContainer = document.getElementById("rainy-countries");
const islandCountriesContainer = document.getElementById("island-countries");
//Render all countries
for (const c of countries) {
    renderCountry(c, allCountriesContainer);
    if (isRainyCountry(c)) {
        rainyCountriesList.push(c);
        renderCountry(c, rainyCountriesContainer);
    }
    else if (isSnowyCountry(c)) {
        snowyCountriesList.push(c);
        renderCountry(c, snowyCountriesContainer);
    }
    else if (isIslandCountry(c)) {
        islandCountriesList.push(c);
        renderCountry(c, islandCountriesContainer);
    }
}
;
//add country to its corresponding list through the country form submission
const form = document.getElementById("addCountryForm");
form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!validateForm())
        return;
    const nameInput = document.getElementById("country-name").value.trim();
    const typeInput = document.getElementById("country-type").value.toLowerCase();
    const measurementInput = parseFloat(document.getElementById("country-measurement").value);
    //Initiate a temporary country variable as a holder
    let newCountry = null;
    //create new country class based on country type when submitted to the form
    switch (typeInput) {
        case "rainy":
            newCountry = new RainyCountry(nameInput, measurementInput);
            break;
        case "snowy":
            newCountry = new SnowyCountry(nameInput, measurementInput);
            break;
        case "island":
            newCountry = new IslandCountry(nameInput, measurementInput);
            break;
    }
    //Add to countries list
    if (newCountry) {
        countries.push(newCountry);
        renderCountry(newCountry, allCountriesContainer);
        if (isRainyCountry(newCountry)) {
            rainyCountriesList.push(newCountry);
            renderCountry(newCountry, rainyCountriesContainer);
        }
        else if (isSnowyCountry(newCountry)) {
            snowyCountriesList.push(newCountry);
            renderCountry(newCountry, snowyCountriesContainer);
        }
        else if (isIslandCountry(newCountry)) {
            islandCountriesList.push(newCountry);
            renderCountry(newCountry, islandCountriesContainer);
        }
        //clear form
        form.reset();
    }
});
function validateForm() {
    let isValid = true;
    const nameInput = document.getElementById("country-name").value.trim();
    const typeInput = document.getElementById("country-type").value.toLowerCase();
    const measurementInput = document.getElementById("country-measurement").value.trim();
    const nameError = document.getElementById("nameError");
    const typeError = document.getElementById("typeError");
    const measurementError = document.getElementById("measurementError");
    if (!nameInput || !(/^[A-Za-z\s]+$/).test(nameInput)) {
        nameError.textContent = 'Text input must be in alphabets';
        isValid = false;
    }
    if (typeInput === "default" || !["rainy", "snowy", "island"].includes(typeInput.toLowerCase())) {
        typeError.textContent = "Please select a valid country type.";
        isValid = false;
        ;
    }
    const measurement = parseFloat(measurementInput);
    if (measurementInput === "" || isNaN(measurement)) {
        measurementError.textContent = "Measurement must be a numeric value.";
        isValid = false;
    }
    if (isValid) {
        const summaryDiv = document.getElementById("summaryMessage");
        if (summaryDiv) {
            summaryDiv.innerHTML = `<p>Country <strong>${nameInput}</strong> has been added to the Data Manager!</p>`;
        }
    }
    if (!isValid) {
        const summaryDiv = document.getElementById("summaryMessage");
        if (summaryDiv)
            summaryDiv.innerHTML = "";
    }
    return isValid;
}
