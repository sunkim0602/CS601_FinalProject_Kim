//receive country object that is of type ICountry and returns a predicate
export function isSnowyCountry(country) {
    //checks which type of country it is
    return country.snowLevel !== undefined;
}
//add countries to rainy countries
export function isRainyCountry(country) {
    return country.rainLevel !== undefined;
}
//add countries to island countries
export function isIslandCountry(country) {
    return country.landSize !== undefined;
}
