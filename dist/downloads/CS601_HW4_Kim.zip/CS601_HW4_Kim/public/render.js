export function renderCountry(country, container) {
    const p = document.createElement("p");
    container === null || container === void 0 ? void 0 : container.appendChild(country.getInfo(p));
}
